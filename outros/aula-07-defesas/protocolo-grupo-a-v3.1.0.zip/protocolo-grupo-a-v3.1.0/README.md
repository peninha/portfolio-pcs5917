# Protocolo 3.1.0 · Grupo A

Comece por [PROTOCOLO.md](PROTOCOLO.md). A última seção de instruções contém o texto para repassar ao seu agente. Para conferir as sete condições sem carregar os pesos, rode na pasta extraída:

    python coleta.py planejar --casos casos.exemplo.json

Para executar os testes offline:

    python -m unittest -q test_defesas test_coleta

A biblioteca de defesa continua na versão 2.0.0. Use coleta.py como ponto de entrada da coleta oficial.

Abra aula-07-ataques-defesas.ipynb para executar as etapas no Jupyter ou VS Code.
